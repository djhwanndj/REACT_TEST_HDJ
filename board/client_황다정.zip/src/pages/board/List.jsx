import React from 'react'
import ListContainer from '../../containers/ListContainer'

const List = () => {
  return (
    <>
      {/* Header */}
      <ListContainer />
      {/* Footer */}
    </>
  )
}

export default List