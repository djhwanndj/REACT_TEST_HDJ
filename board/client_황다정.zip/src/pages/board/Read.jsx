import React from 'react'
import ReadContainer from '../../containers/ReadContainer'
import { useParams } from 'react-router-dom'

const Read = () => {
  const { no } = useParams()
  console.log(`no : ${no}`);
  return (
    <>
      {/* Header */}
      <ReadContainer no={no} />
      {/* Footer */}
    </>
  )
}

export default Read