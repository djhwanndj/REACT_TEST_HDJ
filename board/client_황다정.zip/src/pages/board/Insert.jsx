import React from 'react'
import InsertContainer from '../../containers/InsertContainer'

const Insert = () => {
  return (
    <>
      {/* Header */}
      <InsertContainer/>
      {/* Footer */}
    </>
  )
}

export default Insert